package com.example.ishumishra97.session8assignment2;

import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * Created by ishu.mishra97 on 6/28/2016.
 */
public class UserSettingActivity extends PreferenceActivity{
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.user_settings);


    }
}
